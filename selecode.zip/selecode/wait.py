
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec

# expected_conditions期待的条件，wait等待
import time
#去掉自动化标识
option = Options()
option.add_experimental_option('excludeSwitches', ['enable-automation'])
option.add_argument('--disable-blink-features=AutomationControlled')



driver = webdriver.Chrome()

url = "https://www.baidu.com"

driver.get(url)
driver.maximize_window()
driver.find_element('name',"wd").send_keys("chuyin\n")
# driver.find_element(By.NAME, "wd").send_keys("初音的青葱\n")
# 强制等待
# time.sleep(5)
# yanzheng = driver.find_element('xpath',"//*[@id='")
# act = ActionChains(driver)
# act.click_and_hold(yanzheng)
# act.move_by_offset(380,0)
# act.perform()
# 显式等待-等待某个元素加载完成，每0.5s检查一次，最多5s
# WebDriverWait(driver,5).until(ec.visibility_of_element_located((By.XPATH,'//*[@id="1"]/div/h3/a')))

#隐式等待
driver.implicitly_wait(5)

driver.find_element(By.XPATH,'//*[@id="1"]/div/h3/a').click()
time.sleep(10)
driver.quit()