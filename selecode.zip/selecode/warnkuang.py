#警告框，切换到警告框再操作

#alert = driver.switch_to.alert()

#alert.dismiss()