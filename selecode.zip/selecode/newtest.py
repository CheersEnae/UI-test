file = input("请输入文件名")
oldfile = open(file,"r")
filenum = file.rfind(".")
print(filenum)
newfilename = file[filenum:]
print(newfilename)
