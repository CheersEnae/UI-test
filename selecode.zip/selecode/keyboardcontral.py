from selenium import webdriver
import time

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome()

url = "https://www.baidu.com"
driver.get(url)
print("11111")
el = driver.find_element(By.ID, "kw")
el.send_keys("初音的青葱")
time.sleep(2)
el.send_keys(Keys.CONTROL,"a")
time.sleep(2)
el.send_keys(Keys.CONTROL,"c")
time.sleep(2)
el.send_keys(Keys.BACKSPACE)
time.sleep(2)
el.send_keys("LOL")
time.sleep(2)
el.send_keys(Keys.CONTROL,"a")
time.sleep(2)
el.send_keys(Keys.CONTROL,"v")
time.sleep(2)
el.send_keys(Keys.ENTER)

time.sleep(3)
driver.quit()