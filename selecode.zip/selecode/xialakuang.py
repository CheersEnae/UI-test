from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
# 网页没带有select
driver = webdriver.Chrome()

url = "https://www.lagou.com/wn/"
driver.get(url)
driver.maximize_window()

select = Select(driver.find_element(By.XPATH,'//*[@id="order"]/li/div[2]/div'))
time.sleep(2)
select.select_by_index(3)
time.sleep(2)
select.select_by_value("by")
time.sleep(2)
select.select_by_visible_text("10k-15k")
time.sleep(2)


time.sleep(3)
driver.quit()