from selenium import webdriver
import time
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

# url = "https://www.baidu.com"
url = "https://www.douyu.com/directory/all"
driver.get(url)
driver.maximize_window()

# driver.implicitly_wait(5)
time.sleep(2)
js_str ="window.scrollTo(0,10000)"
driver.execute_script(js_str)
# driver.find_element(By.XPATH,"//*[text()='下一页']").click()
# driver.implicitly_wait(5)
# driver.find_element(By.XPATH,"//*[text()='下一页']").click()

time.sleep(20)
driver.quit()