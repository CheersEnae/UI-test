#框架，嵌套（iframe）https://mail.qq.com/

from selenium import webdriver
import time
from selenium.webdriver.common.by import By
driver = webdriver.Chrome()
driver.maximize_window()
# url = "https://mail.qq.com/"
url1 = "https://xui.ptlogin2.qq.com/cgi-bin/xlogin?appid=716027609&daid=383&style=33&login_text=%E7%99%BB%E5%BD%95&hide_title_bar=1&hide_border=1&target=self&s_url=https%3A%2F%2Fgraph.qq.com%2Foauth2.0%2Flogin_jump&pt_3rd_aid=102013353&pt_feedback_link=https%3A%2F%2Fsupport.qq.com%2Fproducts%2F77942%3FcustomInfo%3D.appid102013353&theme=10&verify_theme="
driver.get(url1)
time.sleep(3)
print(driver.find_element(By.CLASS_NAME,"login_pictures_title").text)
driver.switch_to.frame(driver.find_element(By.XPATH,"//*[@id='QQMailSdkTool_login_loginBox_qq']/iframe"))
time.sleep(2)
# print(driver.find_element(By.ID,"title_0").text)

driver.switch_to.frame(driver.find_element(By.ID,"ptlogin_iframe"))

#退出到上一层
# driver.switch_to.parent_frame()

#退出到最外层frame
driver.switch_to.default_content()
# print(driver.find_element(By.ID,"title_0").text)
# print(driver.find_element(By.CLASS_NAME,"login_pictures_title").text)

# driver.find_element((By.ID,"switcher_plogin")).click()
# driver.find_element(By.XPATH,'//*[@id="bottom_qlogin"]/a[2]').click()
# time.sleep(2)
# driver.find_element(By.XPATH,'//*[@id="u"]').send_keys("123456")
time.sleep(2)
driver.quit()