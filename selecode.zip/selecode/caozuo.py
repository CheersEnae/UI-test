from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
# expected_conditions期待的条件，wait等待
import time

driver = webdriver.Chrome()

url = "https://www.baidu.com"

driver.get(url)
driver.maximize_window()
# driver.find_element(By.NAME, "wd").send_keys("初音的青葱\n")
# time.sleep(3)
# driver.find_element(By.NAME,"wd").clear()
# driver.find_element(By.NAME,"wd").send_keys("崩坏3\n")
print(driver.find_element(By.NAME, "wd").size)
# driver.find_element(By.NAME, "wd").send_keys("初音的青葱")
print(driver.find_element(By.NAME, "wd").text)
print(driver.find_element(By.NAME, "wd").is_enabled())
print(driver.find_element(By.NAME, "wd").is_displayed())
print(driver.find_element(By.XPATH,'//*[@id="s-top-left"]/a[2]').get_attribute("href"))




# 强制等待

# time.sleep(5)

# 显式等待-等待某个元素加载完成，每0.5s检查一次，最多5s
# WebDriverWait(driver,5).until(ec.visibility_of_element_located((By.XPATH,'//*[@id="1"]/div/h3/a')))

#隐式等待
# driver.implicitly_wait(5)

# driver.find_element(By.XPATH,'//*[@id="1"]/div/h3/a').click()
time.sleep(10)
driver.quit()