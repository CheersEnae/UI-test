from selenium import webdriver
import time
from selenium.webdriver.common.by import By
driver = webdriver.Chrome()

url = "https://www.baidu.com"
driver.get(url)
driver.maximize_window()

print(driver.window_handles)
print(driver.current_window_handle)


time.sleep(3)
driver.find_element(By.ID,"kw").send_keys("美女\n")
time.sleep(5)
driver.find_element(By.XPATH,'//*[@id="1"]/div/div[1]/div/div[1]/a[1]/img').click()

driver.switch_to.window(driver.window_handles[1])

driver.implicitly_wait(10)
driver.find_element(By.XPATH,'//*[@id="srcPic"]/img').click()

driver.get_screenshot_as_file("11.png")
time.sleep(5)
driver.quit()