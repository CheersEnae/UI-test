

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# webdriver 获取浏览器的对象
driver = webdriver.Chrome()

# 准备一个网址

# https://www.baidu.com
url = "https://www.baidu.com"
driver.maximize_window()
driver.get(url)
# driver.find_element(By.NAME, "wd").send_keys("初音的青葱")
driver.find_element(By.XPATH,'//*[@id="s-top-left"]/a[1]').click()
time.sleep(5)


# 回收资源
driver.quit()
