import os
import sys
from PIL import Image


def compress_image(infile, a,b,quality1):
    outfile = "压缩后的图片.jpg"
    im = Image.open(infile)
    #计算初始图片的大小，单位为M
    o_size = os.path.getsize(infile)/(1024*1024)
    #如果初始图片的大小小渔传入的最小值，直接返回图片
    if o_size <= a:
        return im.save(outfile, quality=quality1)

    #压缩图片的循环主体
    while 1:
        im = Image.open(infile)
        im.save(outfile, quality=quality1)

        #计算压缩后的文件用于和输入的期望压缩值大小作比较
        o_size1 = os.path.getsize(infile)/(1024*1024)
        if a <= o_size1 <= b:break
        quality1 -= 1
        #压缩比率不能喂负数和小数
        if quality1 < 0:
            break
        print(o_size1,quality1,a,b)
    if __name__ == '__main__':
        #外部参数的输入
        start_node = sys.argv[1]
        end_node = sys.argv[2]
        print("最小值：",start_node,"最大值：",end_node)
        compress_image("10.4M.jpg",int(start_node),int(end_node),100)