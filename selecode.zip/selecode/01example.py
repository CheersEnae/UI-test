from selenium import webdriver
import time

driver = webdriver.Chrome()

url = "https://www.baidu.com"
driver.get(url)
time.sleep(3)
driver.quit()

# from selenium import webdriver
# import time
#
# # webdriver 获取浏览器的对象
# driver = webdriver.Chrome("chromedriver.exe")
#
# # 准备一个网址
#
# # https://www.baidu.com
# url = "https://www.baidu.com"
#
# driver.get(url)
#
# time.sleep(3)
#
# # 回收资源
# driver.quit()
