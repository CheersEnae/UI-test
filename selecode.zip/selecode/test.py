
from selenium import webdriver
print("1")



driver=webdriver.Chrome()

driver.get("")
ele = driver.find_elements('xpath','//')
index = 0
for i in ele:
    if i=="660":

            break
    else:
        index=index+1

print(index)