from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

url = "https://www.baidu.com"

driver.get(url)
driver.maximize_window()

actions = ActionChains(driver)
# actions.context_click(driver.find_element(By.ID,"su"))
actions.move_to_element(driver.find_element(By.CSS_SELECTOR,".soutu-btn"))

actions.perform()
time.sleep(5)
driver.quit()