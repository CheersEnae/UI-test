import  csv


# file = csv.reader(open("aaa.csv" ,"r",encoding="utf-8"))
#
# for cs in file:
#     print(cs)

# import xlrd
# # print("打开excel需要安装xlrd库1.2.0版本pip install xlrd==1.2.0")
# xls = xlrd.open_workbook('aaa.xlsx')
# sheet = xls.sheet_by_index(0)
# print(sheet.nrows)
# print(sheet.ncols)
# # print(sheet.row_values(1))
# for i in range(sheet.nrows):
#     print(sheet.row_values(i))

import json
# json_str2 = '''[{"name": "张三", "age":14},{"name": "李四", "age":15}]'''
json_str = open("aaa.json","r",encoding="utf-8").read()
print(json_str)
print(type(json_str))
# print(json_str2)
json_ob = json.loads(json_str)
print(json_ob[0]["name"])
print(type(json_ob))

print(json.dumps(json_ob,ensure_ascii=False))