from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from datetime import datetime, date, timedelta


# n 就是第几天 n=1明天
def date_n(n):
    return str(date.today() + timedelta(days=int(n)))


driver = webdriver.Chrome()


# 封装定位元素
def name(element):
    return driver.find_element(By.NAME, element)


def xpath(element):
    return driver.find_element(By.XPATH, element)


def book_ticket(start, end, n, username, sfid):
    url = "https://train.qunar.com/"
    driver.get(url)
    driver.maximize_window()
    action = ActionChains(driver)

    # 输入出发站
    driver.implicitly_wait(3)
    name("fromStation").send_keys("北京")
    action.move_by_offset(0, 0)
    action.click()
    action.perform()

    time.sleep(2)
    name("toStation").send_keys("上海")

    time.sleep(2)
    day1 = date_n(2)
    print(day1)
    DAY = name("date")
    DAY.send_keys(Keys.CONTROL, "a")
    DAY.send_keys(day1)

    time.sleep(5)
    name("stsSearch").click()

    driver.implicitly_wait(5)
    xpath('//*[@id="list_listInfo"]/ul[2]/li[1]/div/div[7]/a[1]').click()

    driver.implicitly_wait(5)
    name("pName_0").send_keys("虫洞")
    name("pCertNo_0").send_keys("4444444")

    time.sleep(2)
    driver.quit()


if __name__ == '__main__':
    book_ticket()
