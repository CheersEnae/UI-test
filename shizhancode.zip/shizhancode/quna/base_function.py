from datetime import date, timedelta
from selenium import webdriver
from selenium.webdriver.common.by import By
import xlrd


def date_n(n):
    return str(date.today() + timedelta(days=int(n)))


driver = webdriver.Chrome()


def get_driver():
    return driver


def name(element):
    return driver.find_element(By.NAME, element)


def xpath(element):
    return driver.find_element(By.XPATH, element)


def openurl(url):
    driver.get(url)
    driver.maximize_window()


def close():
    driver.close()


#ifhead
def read_excel(filename,index,ishead = False):
        xls = xlrd.open_workbook(filename)
        sheet = xls.sheet_by_index(index)
        date = []
        for i in range(sheet.nrows):
            if i == 0:
                if ishead:
                    continue
            date.append(sheet.row_values(i))
        return date

if __name__ == '__main__':
    print(read_excel("testexample.xlsx",0,True))
