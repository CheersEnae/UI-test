from selenium.webdriver.common.action_chains import ActionChains
from quna.base_function import *
from selenium.webdriver.common.keys import Keys
import time


def book_ticket(start, end, n, username, sfid):
    driver = get_driver()
    url = "https://train.qunar.com/"
    openurl(url)
    action = ActionChains(driver)

    #
    driver.implicitly_wait(3)
    name("fromStation").clear()
    name("fromStation").send_keys(start)
    # action.move_by_offset(0, 500)
    # action.click()
    # action.perform()

    time.sleep(2)
    name("toStation").clear()
    name("toStation").send_keys(end)

    time.sleep(2)
    day1 = date_n(n)
    # print(day1)
    DAY = name("date")
    DAY.send_keys(Keys.CONTROL, "a")
    DAY.send_keys(day1)

    time.sleep(5)
    name("stsSearch").click()

    driver.implicitly_wait(5)
    xpath('//*[@id="list_listInfo"]/ul[2]/li[1]/div/div[7]/a[1]').click()

    driver.implicitly_wait(5)
    name("pName_0").send_keys(username)
    name("pCertNo_0").send_keys(sfid)

    time.sleep(5)
    # close()
