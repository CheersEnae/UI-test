from quna.quna_book import book_ticket
from quna.base_function import read_excel
import pytest

date = read_excel("testexample.xlsx",0,True)

@pytest.mark.parametrize(["start","end","n","username","stid"],date)
def test_book_ticket(start,end,n,username,stid):

    book_ticket(start,end,n,username,stid)

if __name__ == '__main__':
    pytest.main(["-s","test_quna.py"])
