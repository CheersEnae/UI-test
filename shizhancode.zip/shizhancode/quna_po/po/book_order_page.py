import time

from quna_po.base.base import Base
class BookOrder(Base):
    def book_username(self):
        return self.byname("pName_0")
    def book_sfid(self):
        return self.byname("pCertNo_0")
    def book_order(self,username,sfid):
        self.book_username().send_keys(username)
        self.book_sfid().send_keys(sfid)
        time.sleep(2)