from selenium.webdriver.common.keys import Keys
from quna_po.base.base import *
from selenium.webdriver.common.action_chains import ActionChains

import time
class BookTicket(Base):

    def book_start(self):
        return self.byname("fromStation")
    def book_end(self):
        return self.byname("toStation")
    def move_click(self):
        action = ActionChains(self.driver)
        action.move_by_offset(0,0)
        action.click()
        action.perform()
    def book_date(self,date):
        DAY = self.byname("date")
        DAY.send_keys(Keys.CONTROL, "a")
        DAY.send_keys(date)
    def book_button(self):
        return self.byname("stsSearch")

    def book_ticket(self,start,end,date):
        # url = "https://train.qunar.com/"
        # self.openurl(url)
        time.sleep(5)
        self.book_start().send_keys(start)
        self.move_click()

        time.sleep(2)
        self.book_end().send_keys(end)
        self.move_click()

        time.sleep(2)
        self.book_date(date)
        self.book_button().click()
        time.sleep(2)



