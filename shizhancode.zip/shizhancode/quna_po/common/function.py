from datetime import date, timedelta
import xlrd


def date_n(n):
    return str(date.today() + timedelta(days=int(n)))

def read_excel(filename, index, ishead=False):
        xls = xlrd.open_workbook(filename)
        sheet = xls.sheet_by_index(index)
        date = []
        for i in range(sheet.nrows):
            if i == 0:
                if ishead:
                    continue
            date.append(sheet.row_values(i))
        return date