from selenium import webdriver
from quna_po.po.book_ticket_page import BookTicket
from quna_po.po.book_list_page import BookList
from quna_po.po.book_order_page import BookOrder
from quna_po.common.function import read_excel,date_n
import pytest

data = read_excel("../data/testexample.xlsx",0,True)
class TestBookTicket():
    def setup(self):
        self.driver = webdriver.Chrome()
        url = "https://train.qunar.com/"
        self.driver.get(url)
        self.driver.maximize_window()

    @pytest.mark.parametrize(["start","end","n","username","sfid"],data)
    def test_01(self,start,end,n,username,sfid):
        ticket = BookTicket(self.driver)
        ticket.book_ticket(start,end,date_n(n))

        list_a = BookList(self.driver)
        list_a.book_list()
        order = BookOrder(self.driver)
        order.book_order(username,sfid)
    def teardown(self):
        self.driver.quit()

if __name__ == '__main__':
    pytest.main(["-s","test_book_ticket.py"])