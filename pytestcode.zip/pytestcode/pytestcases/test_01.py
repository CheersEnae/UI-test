import pytest
#规则Test
#@pytest.mark.skip/skipif标记跳过
#@pytest.mark.run（order=下标）执行顺序
#@pytest.mark.xfail标记失败
#@pytest.mark.parametrize标记参数化，
#@pytest.mark.setup/teardown前置/后置固件


# @pytest.fixture(scope="作用域", autouse="是否自动使用", params="参数值",
#                 ids="参数编号",name="固件的别名")
#yield不是最好的,最好是用teardown和setup加上reques.addfinallizer
@pytest.fixture(scope="function",autouse=True)#function针对函数或方法
def exe_sql():
    print("对数据校验")
    yield
    print("关闭数据库")
#用例执行完成对数据库的数据校验
#用例执行完成对数据库的关闭操作

@pytest.mark.xfail(reason="0不能除")
def test_fun1():
    print("1111")
    print(1/0)

@pytest.mark.skip(reason="反例跳过不执行")
def test_fun2():
    print("22222")

# @pytest.mark.parametrize(argnames="用例形参",argvalues="具体实参",ids="参数执行用例编号")
@pytest.mark.parametrize(["x","y"],[(11,23),(4,6),(222,555)],ids="abc")
def test_fun5(x,y):
    print(f"x:{x},y:{y},x+y:{x+y}")
    print("555555")

class Test_001():

    @pytest.mark.xfail()
    @pytest.mark.run(order=-1)
    def test_fun3(self):
        print("33333")

    @pytest.mark.run(order=1)
    @pytest.mark.skipif(2>10,reason="反例跳过不执行")
    def test_fun4(self):
        print("44444")
        assert 1 == 0