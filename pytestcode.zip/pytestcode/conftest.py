#这个是管理夹具存在的文件
import pytest

# @pytest.fixture(scope="作用域", autouse="是否自动使用", params="参数值",
#                 ids="参数编号",name="固件的别名")
@pytest.fixture(scope="function",autouse=True)#function针对函数或方法
def exe_sql():
    print("对数据校验")
    yield
    print("关闭数据库")
#用例执行完成对数据库的数据校验
#用例执行完成对数据库的关闭操作