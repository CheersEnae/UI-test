from appium import webdriver
import time
from appium.webdriver.common.appiumby import By
#链接移动设备所必须的参数
desired_caps={}
# desired_caps=dict["DeviceName":'127.0.0.1:62001',
# "platformName":'Android',
# "platformVersion":'7.1',
# "appPackage":'com.android.browser',
# "appActivity":'.BrowserActivity']
# #设备名称,系统,系统版本,要启动app名称(标识:包名),要启动的app的哪个界面
desired_caps["deviceName"]="127.0.0.1:62001"
desired_caps["platformName"]="Android"
desired_caps["platformVersion"]="7.1"
desired_caps["appPackage"]="com.android.launcher3"
desired_caps["appActivity"]=".launcher3.Launcher"


driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub",desired_capabilities=desired_caps)
time.sleep(4)
start1 = driver.find_element(By.XPATH,"//*[@text='浏览器']")
# start1 = driver.find_element(By.XPATH,"//*[@text='浏览器']")
end1 = driver.find_element(By.XPATH,"//*[@text='哔哩哔哩']")

driver.drag_and_drop(start1,end1)
time.sleep(4)

driver.close_app()
driver.quit()

