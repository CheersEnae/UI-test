from appium import webdriver
import time
from appium.webdriver.common.appiumby import By
from appium.webdriver.common.touch_action import TouchAction
#链接移动设备所必须的参数
desired_caps={}
# desired_caps=dict["DeviceName":'127.0.0.1:62001',
# "platformName":'Android',
# "platformVersion":'7.1',
# "appPackage":'com.android.browser',
# "appActivity":'.BrowserActivity']
# #设备名称,系统,系统版本,要启动app名称(标识:包名),要启动的app的哪个界面
desired_caps["deviceName"]="127.0.0.1:62001"
desired_caps["platformName"]="Android"
desired_caps["platformVersion"]="7.1"
desired_caps["appPackage"]="com.android.settings"
desired_caps["appActivity"]=".Settings"


driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub",desired_capabilities=desired_caps)
time.sleep(3)

ele1 = driver.find_element(By.XPATH,"//*[@text='通知']")
ele2 = driver.find_element(By.XPATH,"//*[@text='WLAN']")

#实例化TouchAction
action = TouchAction(driver)
#移动过程中wait是必要的
# action.press(ele1).wait(500).move_to(ele2)
action.press(x=300,y=1060).wait(500).move_to(x=300,y=530)

action.release()
action.perform()

time.sleep(2)
#press 可以用元素也可以用坐标

driver.close_app()
driver.quit()

