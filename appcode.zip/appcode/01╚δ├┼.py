from appium import webdriver
import time
#链接移动设备所必须的参数
desired_caps={}
# desired_caps=dict["DeviceName":'127.0.0.1:62001',
# "platformName":'Android',
# "platformVersion":'7.1',
# "appPackage":'com.android.browser',
# "appActivity":'.BrowserActivity']
# #设备名称,系统,系统版本,要启动app名称(标识:包名),要启动的app的哪个界面
desired_caps["deviceName"]="127.0.0.1:62001"
desired_caps["platformName"]="Android"
desired_caps["platformVersion"]="7.1"
desired_caps["appPackage"]="com.android.settings"
desired_caps["appActivity"]=".Settings"


driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub",desired_capabilities=desired_caps)
time.sleep(10)
print(driver.page_source)
driver.close_app()
driver.quit()

